# Allora

```
rm -f allora_installer_*
wget https://raw.githubusercontent.com/batuoc263/T4E-Nodes/main/Allora/script/allora_installer_offical.sh && sudo chmod +x allora_installer_offical.sh && ./allora_installer_offical.sh
```

# Install mới

Step 1:

Replace funding Wl:
```
rm -f replace_fundingWl.sh && wget https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/master/dashboard-example/script/replace_fundingWl.sh -O replace_fundingWl.sh && chmod +x replace_fundingWl.sh && ./replace_fundingWl.sh
```
Fund:
```
rm -f funding.sh && wget https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/master/dashboard-example/script/funding.sh -O funding.sh && chmod +x funding.sh && ./funding.sh
```

Step 2:

# Install from old wallet

## Step 1:
Paste to `$HOME/wl_formated.txt` with format: `address|mnemonic`
Then run:
```bash
rm -f config-from-old-wl.sh && wget https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/master/dashboard-example/script/config-from-old-wl.sh -O config-from-old-wl.sh && chmod +x config-from-old-wl.sh && ./config-from-old-wl.sh
```

## Step 2:
```bash
rm -f reload-docker-compose.sh && wget https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/master/dashboard-example/script/reload-docker-compose.sh -O reload-docker-compose.sh && chmod +x reload-docker-compose.sh && ./reload-docker-compose.sh
```

# Update
## Change `app.py`
```bash
cd $HOME/allora-huggingface-walkthrough
rm -f requirements.txt && wget https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/master/dashboard-example/script/requirements.txt
rm -f app.py && wget https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/master/dashboard-example/script/app.py
rm -f upshot_key.txt && wget https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/master/dashboard-example/script/upshot_key.txt
```
Rebuild Docker:
```
docker compose up --build -d
```

## Add topic:
```bash
rm -f add-topic.sh && wget https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/master/dashboard-example/script/add-topic.sh -O add-topic.sh && chmod +x add-topic.sh && ./add-topic.sh
```
Paste new topic (JSON minified)

## Update RPC
**Single RPC**
```bash
rm -f replace-rpc.sh && wget https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/master/dashboard-example/script/replace-rpc.sh -O replace-rpc.sh && chmod +x replace-rpc.sh && ./replace-rpc.sh
```
Paste new PRC

**Multi RPC:**
```bash
rm -f $HOME/allora-huggingface-walkthrough/rpc_list.txt && wget -O $HOME/allora-huggingface-walkthrough/rpc_list.txt https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/master/dashboard-example/script/rpc_list
rm -f multi_rpc_replace.sh && wget -O multi_rpc_replace.sh https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/refs/heads/master/dashboard-example/script/multi_rpc_replace.sh && chmod +x multi_rpc_replace.sh && ./multi_rpc_replace.sh
```

## MUST reload docker-compose file
```bash
rm -f reload-docker-compose.sh && wget https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/master/dashboard-example/script/reload-docker-compose.sh -O reload-docker-compose.sh && chmod +x reload-docker-compose.sh && ./reload-docker-compose.sh
```

## Check logs
```bash
rm -f check_logs.sh && wget -O check_logs.sh https://raw.githubusercontent.com/batuoc263/prometheus-grafana-installer/refs/heads/master/dashboard-example/script/check_logs.sh && chmod +x check_logs.sh && ./check_logs.sh
```