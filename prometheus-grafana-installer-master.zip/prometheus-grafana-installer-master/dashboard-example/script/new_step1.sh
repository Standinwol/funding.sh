#!/bin/bash

BOLD="\033[1m"
UNDERLINE="\033[4m"
DARK_YELLOW="\033[0;33m"
CYAN="\033[0;36m"
RESET="\033[0;32m"

NODE_URL="https://allora-rpc.testnet.allora.network/"

echo "NODE_URL: $NODE_URL"

curl -sSL https://raw.githubusercontent.com/allora-network/allora-chain/main/install.sh | bash -s -- v0.5.0
echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bash_profile
source ~/.bash_profile

echo -e "${BOLD}${UNDERLINE}${DARK_YELLOW}Installing worker node...${RESET}"
cd
rm -rf allora-huggingface-walkthrough
git clone https://github.com/allora-network/allora-huggingface-walkthrough.git
cd allora-huggingface-walkthrough

rm -f app.py
wget https://raw.githubusercontent.com/batuoc263/T4E-Nodes/main/Allora/script/app.py

echo 

echo -e "${BOLD}${DARK_YELLOW}Tao vi funding${RESET}"
funding=$(allorad keys show fundingWl -a --keyring-backend test 2>/dev/null)
if [ -z "$funding" ]; then
    echo "Import vi funding:"
    allorad keys add fundingWl --recover --keyring-backend test
    wait
else
    echo "Vi funding da ton tai: $funding"
fi


i=1
read -p "Nhap so luong vi muon khoi tao: " quantities
while [ $i -le $quantities ]
do
    echo "=====Config Wallet $i======"
    echo "Xoa vi cu neu co"
    echo y | allorad keys delete wl$i --keyring-backend test  2>/dev/null
    wallet_info=$(allorad keys add wl$i --keyring-backend test --output json | jq)
    echo $wallet_info >> $HOME/wl.txt
    name=$(echo "$wallet_info" | jq -r '.name')
    address=$(echo "$wallet_info" | jq -r '.address')
    mnemonic=$(echo "$wallet_info" | jq -r '.mnemonic')
    echo "$address|$mnemonic" >> $HOME/wl_formated.txt
    echo "WalletName: $name"
    echo "Address: $address"
    sleep 2
    allorad tx bank send fundingWl $(allorad keys show wl$i -a --keyring-backend test) 10000000000000000uallo --chain-id allora-testnet-1 --keyring-backend test --node $NODE_URL --gas-prices 1000000uallo --gas 1000000 -y

    if [ -f config.json ]; then
        rm config.json
        echo "Removed existing config.json file."
    fi
    cat <<EOF > wl_${i}_config-both.json
{
    "wallet": {
        "addressKeyName": "$name",
        "addressRestoreMnemonic": "$mnemonic",
        "alloraHomeDir": "",
        "gas": "1000000",
        "gasAdjustment": 1.0,
        "nodeRpc": "$NODE_URL",
        "maxRetries": 2,
        "delay": 1,
        "submitTx": true
    },
    "worker": [
        {
            "topicId": 1,
            "inferenceEntrypointName": "api-worker-reputer",
            "loopSeconds": 15,
            "parameters": {
                "InferenceEndpoint": "http://inference:8000/inference/{Token}",
                "Token": "ETH"
            }
        },
        {
            "topicId": 3,
            "inferenceEntrypointName": "api-worker-reputer",
            "loopSeconds": 15,
            "parameters": {
                "InferenceEndpoint": "http://inference:8000/inference/{Token}",
                "Token": "BTC"
            }
        },
        {
            "topicId": 5,
            "inferenceEntrypointName": "api-worker-reputer",
            "loopSeconds": 15,
            "parameters": {
                "InferenceEndpoint": "http://inference:8000/inference/{Token}",
                "Token": "SOL"
            }
        },
        {
            "topicId": 7,
            "inferenceEntrypointName": "api-worker-reputer",
            "loopSeconds": 15,
            "parameters": {
                "InferenceEndpoint": "http://inference:8000/inference/{Token}",
                "Token": "ETH"
            }
        },
        {
            "topicId": 8,
            "inferenceEntrypointName": "api-worker-reputer",
            "loopSeconds": 15,
            "parameters": {
                "InferenceEndpoint": "http://inference:8000/inference/{Token}",
                "Token": "BNB"
            }
        },
        {
            "topicId": 9,
            "inferenceEntrypointName": "api-worker-reputer",
            "loopSeconds": 15,
            "parameters": {
                "InferenceEndpoint": "http://inference:8000/inference/{Token}",
                "Token": "ARB"
            }
        },
        {
            "topicId": 10,
            "inferenceEntrypointName": "api-worker-reputer",
            "loopSeconds": 5,
            "parameters": {
                "InferenceEndpoint": "http://inference:8000/inference/{BlockHeight}"
            }
        },
        {
            "topicId": 11,
            "inferenceEntrypointName": "api-worker-reputer",
            "loopSeconds": 5,
            "parameters": {
                "InferenceEndpoint": "http://inference:8000/inference/{Party}"
            }
        }
    ]
}
EOF
    sleep 1
    ((i++))
done

for j in {1..10}
do
    i=1
    while [ $i -le $quantities ]
    do
        while true
            do
                # Get the current wallet address
                CURRENT_WALLET=$(allorad keys show wl$i -a --keyring-backend test)
                
                # Check the balance of the current wallet
                BALANCE_OUTPUT=$(allorad query bank balances $CURRENT_WALLET --node=$NODE_URL)
                
                # Check if the balance is empty
                if echo "$BALANCE_OUTPUT" | grep -q "balances: \[\]"; then
                echo "Balance is empty for wallet $CURRENT_WALLET, sending funds..."

                # Send the transaction from the fundingWl to the current wallet
                allorad tx bank send fundingWl $(allorad keys show wl$i -a --keyring-backend test) 10000000000000000uallo --chain-id allora-testnet-1 --keyring-backend test --node $NODE_URL --gas-prices 1000000uallo --gas 100000 -y
                sleep 3
                # Check if the transaction was successful
                if [ $? -eq 0 ]; then
                    echo "Transaction successful to $CURRENT_WALLET."
                    break
                else
                    echo "Transaction failed to $CURRENT_WALLET, retrying..."
                fi
                else
                echo "Balance is not empty for wallet $CURRENT_WALLET, no need to send funds."
                break
                fi
            done
        ((i++))
    done
done