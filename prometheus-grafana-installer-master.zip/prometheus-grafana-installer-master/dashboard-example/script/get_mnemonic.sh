#!/bin/bash

read -p "Nhap duong dan vi, ex: allora-wallets: " wallet_dir
for json_file in "$wallet_dir"/wl_*.json; do

    mnemonic=$(jq -r '.wallet.addressRestoreMnemonic' "$json_file")
    echo "$mnemonic"
done
