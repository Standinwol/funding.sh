#!/bin/bash

# Di chuyen vao thu muc $HOME/allora-huggingface-walkthrough
cd $HOME/allora-huggingface-walkthrough

# Thoi gian bat dau tinh tu hien tai (trong 30 phut)
time_limit=$(date --date="30 minutes ago" +"%Y-%m-%dT%H:%M")

# Lay tat ca cac service trong docker-compose
services=$(docker-compose ps --services)

# Khai bao cac mang luu tru service co va khong co log "Success"
services_with_success=()
services_without_success=()

# Vong lap de kiem tra log cua tung service
for service in $services; do
    # Lay log cua service trong vong 30 phut
    logs=$(docker-compose logs --since "$time_limit" $service)

    # Kiem tra neu co log chua "message":"Success"
    if echo "$logs" | grep -q '"message":"Success"'; then
        services_with_success+=($service)
    else
        services_without_success+=($service)
    fi
done

# Hien thi ket qua
echo "Cac service co log 'Success':"
for service in "${services_with_success[@]}"; do
    echo $service
done

echo ""
echo "Cac service KHONG co log 'Success':"
for service in "${services_without_success[@]}"; do
    echo $service
done
