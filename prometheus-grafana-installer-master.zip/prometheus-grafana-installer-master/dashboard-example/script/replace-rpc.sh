#!/bin/bash

dir_path="$HOME/allora-huggingface-walkthrough"

echo "Enter new nodeRpc:"
read -r new_nodeRpc

for file in "$dir_path"/wl_*.json; do
    echo "Updating file $file..."

    jq --arg new_nodeRpc "$new_nodeRpc" '.wallet.nodeRpc = $new_nodeRpc' "$file" > "${file}.tmp" && mv "${file}.tmp" "$file"
done

echo "Done."
