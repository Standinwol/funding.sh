#!/bin/bash

# Đường dẫn tới thư mục
dir_path="$HOME/allora-huggingface-walkthrough"

# File chứa danh sách RPC
rpc_file="$dir_path/rpc_list.txt"
rm -f "$rpc_file" && touch "$rpc_file"

# Tải JSON từ URL
json_data=$(curl -s https://server-3.itrocket.net/testnet/allora/.rpc_combined.json)

# Trích xuất 250 RPC đầu tiên có tx_index == "on"
endpoints=$(echo "$json_data" | jq -r '
  to_entries 
  | map(select(.value.tx_index == "on")) 
  | sort_by(.value.latest_block_height | tonumber) 
  | reverse 
  | .[:250]  # Lấy 250 phần tử đầu tiên
  | .[].key
  | "http://" + .
')

# Lưu danh sách đầy đủ vào một file tạm thời
tmp_file=$(mktemp)
echo "$endpoints" > "$tmp_file"

# Sử dụng `shuf` để lấy 100 endpoint ngẫu nhiên từ 250 RPC đầu tiên
shuf -n 100 "$tmp_file" > "$rpc_file"

# Thêm các endpoint cố định
echo "https://rpc.ankr.com/allora_testnet" >> "$rpc_file"
echo "https://allora-testnet-rpc.itrocket.net" >> "$rpc_file"

# Kiểm tra nếu file đã được tạo thành công
if [ ! -f "$rpc_file" ]; then
    echo "File rpc_list.txt không tồn tại!"
    exit 1
fi

# Tải danh sách RPC vào mảng
mapfile -t rpc_list < "$rpc_file"
num_files=$(ls "$dir_path"/wl_*.json | wc -l)
num_rpcs=${#rpc_list[@]}

# Kiểm tra số lượng file và RPC
if [ "$num_files" -gt "$num_rpcs" ]; then
    echo "Không đủ RPC trong rpc_list.txt để thay thế tất cả các file config!"
    exit 1
fi

# Hàm lấy RPC ngẫu nhiên
get_random_rpc() {
    local rpc_index=$((RANDOM % ${#rpc_list[@]}))
    local rpc_value=${rpc_list[$rpc_index]}
    unset rpc_list[$rpc_index]
    rpc_list=("${rpc_list[@]}")
    echo "$rpc_value"
}

# Cập nhật các file cấu hình
for file in "$dir_path"/wl_*.json; do
    echo "Updating file $file..."
    
    new_nodeRpc=$(get_random_rpc)
    
    jq --arg new_nodeRpc "$new_nodeRpc" '.wallet.nodeRpc = $new_nodeRpc' "$file" > "${file}.tmp" && mv "${file}.tmp" "$file"

    if [ $? -eq 0 ]; then
        echo "Successfully updated $file with new RPC: $new_nodeRpc"
    else
        echo "Failed to update $file"
        exit 1
    fi
done

echo "All config files have been updated."
