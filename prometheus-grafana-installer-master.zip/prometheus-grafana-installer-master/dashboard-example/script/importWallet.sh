#!/bin/bash

filename=$HOME/list.txt
i=1

while IFS= read -r line; do
    echo "Import"
    echo "Line: $line"
    allorad keys add wl$i --recover --keyring-backend test <<!
    $line
!
echo "Import success"
((i++))
done < "$filename"

NUM_WL=$(wc -l < $HOME/list.txt)

i=1
while [ $i -le $NUM_WL ]
do
    allorad keys show wl$i -a --keyring-backend test
    ((i++))
done