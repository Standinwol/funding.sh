#!/bin/bash

read -p "Nhap so luong vi da khoi tao: " quantities

i=1
while [ $i -le $quantities ]
do
    echo "============"
    echo $(allorad keys add wl$i --keyring-backend test --output json | jq) >> $HOME/wl.txt
    sleep 1
    ((i++))
done