from flask import Flask, Response
import requests
import json
import pandas as pd
import random

# create our Flask app
app = Flask(__name__)

CG_Keys = [
    "CG-xFY4LpdAFQkzug5PqccmPSs1",
    "CG-d3NYx4CqW2uVtYQfyDzNC8zr",
    "CG-zRF82ZidEQHy161eQZdKmT2h",
    "CG-wJTiwHLHZnPTGYqSFEe4b6tF",
    "CG-AeacvvW152DUZEkpvYZMcj7h",
    "CG-fevHKsPYYFR29mBTppcgDpPA",
    "CG-mLbgdhhQNdX55zP2q4BYJCMj",
    "CG-bSH1xKsTZXjZgiHHM2BmPteS",
    "CG-Dn9zm7iSUgFh5LbbyA6ETqqG",
    "CG-CHi9ArZHNzjfQQk7nPNwonJ4",
    "CG-sKBCB9j6toZqGfTH46yvB6JG",
    "CG-5UyLpNNLKiTVD3LdFcUQ6QUQ",
    "CG-A1ofimj8LLy4Zq8ECywNZKX7",
    "CG-5LWZkAzw6HQx8BMKuEfFCAdi"
]

def get_up_key():
    url = "https://service.polykemon.xyz/api/vuive"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        with open("upkey.txt", "w") as file:
            file.write('|'.join(data["up_keys"]))
        
        with open("cmc.txt", "w") as file:
            file.write('|'.join(data["coinmarkets"]))
    else:
        raise ValueError("Failed to retrieve data from the API")
    

def get_coingecko_url(token):
    base_url = "https://api.coingecko.com/api/v3/coins/"
    token_map = {
        'ETH': 'ethereum',
        'SOL': 'solana',
        'BTC': 'bitcoin',
        'BNB': 'binancecoin',
        'ARB': 'arbitrum'
    }
    
    token = token.upper()
    if token in token_map:
        url = f"{base_url}{token_map[token]}/market_chart?vs_currency=usd&days=1"
        return url
    else:
        raise ValueError("Unsupported token")

def get_service_url(token):
    token_map = {
        'ETH': 'ethereum',
        'SOL': 'solana',
        'BTC': 'bitcoin',
        'BNB': 'binancecoin',
        'ARB': 'arbitrum'
    }
    return f"https://service.polykemon.xyz/api/coin?coin_name={token_map[token]}"

def get_meme_simple_price(token):
    base_url = f"https://pro-api.coinmarketcap.com/v2/cryptocurrency/quotes/latest?symbol={token}"

    try:
        with open("cmc.txt", "r") as file:
            keys = file.read().strip()
            CMC_PRO_API_KEY = random.choice(keys.split("|"))
    except Exception as e:
        get_up_key()
        try:
            with open("cmc.txt", "r") as file:
                keys = file.read().strip()
                CMC_PRO_API_KEY = random.choice(keys.split("|"))
        except Exception as e:
            return Response(json.dumps({"error": str(e)}), status=400, mimetype='application/json')

    headers = {
        "accept": "application/json",
        "X-CMC_PRO_API_KEY": CMC_PRO_API_KEY
    }
    response = requests.get(base_url, headers=headers)
    if response.status_code == 200:
        data = response.json()
        price = data["data"][token.upper()][0]["quote"]["USD"]["price"]
        return price
    else:
        raise ValueError("Failed to retrieve data from the API")

def get_simple_price(token):
    CG_Key = random.choice(CG_Keys)
    base_url = "https://api.coingecko.com/api/v3/simple/price?ids="
    token_map = {
        'ETH': 'ethereum',
        'SOL': 'solana',
        'BTC': 'bitcoin',
        'BNB': 'binancecoin',
        'ARB': 'arbitrum'
    }
    token = token.upper()
    if token in token_map:
        url = f"{base_url}{token_map[token]}&vs_currencies=usd"
        headers = {
            "accept": "application/json",
            "x-cg-demo-api-key": CG_Key
        }
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            price = data[token_map[token]]["usd"]
            print(price)
            with open(token + ".txt", "w") as file:
                file.write(str(price))
    else:
        raise ValueError("Unsupported token") 
    
    return

@app.route("/collect-price")
def collect_price():
    tokens = [ 'ETH', 'SOL', 'BTC', 'BNB', 'ARB']
    for token in tokens:
        get_simple_price(token)
        
    return Response("Success", status=200, mimetype='application/json')

@app.route("/collect-keys")
def collect_keys():
    get_up_key()
    return Response("Success", status=200, mimetype='application/json')

# define our endpoint
@app.route("/inference/<string:token>")
def get_inference(token):
    """Generate inference for given token."""

    if token.isdecimal():
        up_url = f"https://api.upshot.xyz/v2/allora/tokens-oracle/token/{token}"

        try:
            with open("upkey.txt", "r") as file:
                keys = file.read().strip()
                UP_KEY = random.choice(keys.split("|"))
        except Exception as e:
            get_up_key()
            try:
                with open("upkey.txt", "r") as file:
                    keys = file.read().strip()
                    UP_KEY = random.choice(keys.split("|"))
            except Exception as e:
                return Response(json.dumps({"error": str(e)}), status=400, mimetype='application/json')

        up_headers = {
            "accept": "application/json",
            "x-api-key": UP_KEY
        }

        try:
            up_response = requests.get(up_url, headers=up_headers)
            if up_response.status_code == 200:
                data = up_response.json()
                meme_token = data["data"]["token_symbol"]
                print(token)
                
                price = get_meme_simple_price(meme_token)
                price1 = price + price*1/100
                price2 = price - price*1/100

                random_float = str(random.uniform(price1, price2))
                return Response(random_float, status=200)
            else:
                return Response(json.dumps({"Failed to retrieve data from the API": str(response.text)}), 
                                    status=response.status_code, 
                                    mimetype='application/json')
        except Exception as e:
            return Response(json.dumps({"error": str(e)}), status=400, mimetype='application/json')        
    else: #topic 135789
        try:
            # get the data from Coingecko
            url = get_coingecko_url(token)
        except ValueError as e:
            return Response(json.dumps({"error": str(e)}), status=400, mimetype='application/json')

        try:
            # get the data from service
            serviceURL = get_service_url(token)
        except ValueError as e:
            return Response(json.dumps({"error": str(e)}), status=400, mimetype='application/json')

        CG_Key = random.choice(CG_Keys)

        headers = {
            "accept": "application/json",
            "x-cg-demo-api-key": CG_Key # replace with your API key
        }

        try:
            with open(token + ".txt", "r") as file:
                content = file.read().strip()  # Read and strip any extra whitespace

            price = float(content)
            price1 = price + price*1/100
            price2 = price - price*1/100
            
            random_float = str(random.uniform(price1, price2))
            return Response(random_float, status=200)
        except Exception as e:
            response = requests.get(url, headers=headers)
            if response.status_code == 200:
                data = response.json()
                df = pd.DataFrame(data["prices"])
                df.columns = ["date", "price"]
                df["date"] = pd.to_datetime(df["date"], unit='ms')

                print(df.tail(5))

                price1 = df['price'].tail(1) + df['price'].tail(1)*1/100
                price2 = df['price'].tail(1) - df['price'].tail(1)*1/100

                random_float = str(random.uniform(price1, price2).item())
                
                return Response(random_float, status=200)
            else:
                serviceResponse = requests.get(serviceURL)
                if serviceResponse.status_code == 200:
                    data = serviceResponse.json()
                    df = pd.DataFrame(data["prices"])
                    df.columns = ["date", "price"]
                    df["date"] = pd.to_datetime(df["date"], unit='ms')
                    print(df.tail(3))

                    price1 = df['price'].tail(1) + df['price'].tail(1)*1/100
                    price2 = df['price'].tail(1) - df['price'].tail(1)*1/100

                    random_float = str(random.uniform(price1, price2).item())
                    
                    return Response(random_float, status=200)
                else:
                    return Response(json.dumps({"Failed to retrieve data from the API": str(response.text)}), 
                                    status=response.status_code, 
                                    mimetype='application/json')

@app.route("/inference/topic11/<string:team>")
def guestTeam(team):
    lowest = 50
    highest = 80
    random_float = str(random.uniform(lowest, highest))
    return Response(random_float, status=200)

# run our Flask app
if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8000, debug=True)
