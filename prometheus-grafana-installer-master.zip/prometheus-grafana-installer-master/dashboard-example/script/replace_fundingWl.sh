#!/bin/bash

echo "Xoa vi cu neu co"
echo y | allorad keys delete fundingWl --keyring-backend test  2>/dev/null

echo "Import vi funding:"
allorad keys add fundingWl --recover --keyring-backend test
wait