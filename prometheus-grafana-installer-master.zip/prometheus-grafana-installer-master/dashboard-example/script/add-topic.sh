#!/bin/bash

dir_path="$HOME/allora-huggingface-walkthrough"

echo "Nhap JSON cho phan tu worker moi (JSON minified):"
read -r new_worker

for file in "$dir_path"/wl_*.json; do
    echo "Thêm topicId $new_topicId vào file $file."
    jq --argjson new_worker "$new_worker" '.worker += [$new_worker]' "$file" > "${file}.tmp" && mv "${file}.tmp" "$file"
done